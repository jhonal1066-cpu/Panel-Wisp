-- ============================================================
-- Alinet Telecom Manager (WISP)
-- Tabla: clientes (suscriptores)
-- Ejecutar en: Supabase Dashboard > SQL Editor
-- ============================================================

-- Tipos enumerados para consistencia de datos
create type public.estado_cliente as enum ('Activo', 'Suspendido', 'Retirado');

create table public.clientes (
    id uuid primary key default gen_random_uuid(),
    nombre_completo text not null,
    cedula_identidad text not null unique,
    direccion text not null,
    telefono text not null,
    ip_asignada inet not null unique,
    mac_cpe macaddr not null,
    plan_contratado text not null,          -- Ej: '3Mbps', '5Mbps', '10Mbps'
    estado public.estado_cliente not null default 'Activo',
    fecha_instalacion timestamptz not null default now(),
    created_at timestamptz not null default now(),
    updated_at timestamptz not null default now()
);

-- Permisos para la API de datos (PostgREST)
grant select, insert, update, delete on public.clientes to authenticated;
grant all on public.clientes to service_role;

-- Seguridad a nivel de fila (RLS)
alter table public.clientes enable row level security;

-- Política: usuarios autenticados del WISP pueden gestionar clientes
create policy "Usuarios autenticados gestionan clientes"
on public.clientes
for all
to authenticated
using (true)
with check (true);

-- Trigger para actualizar updated_at automáticamente
create or replace function public.set_updated_at()
returns trigger
language plpgsql
as $$
begin
    new.updated_at = now();
    return new;
end;
$$;

create trigger trg_clientes_updated_at
before update on public.clientes
for each row execute function public.set_updated_at();

-- Índices útiles para búsquedas frecuentes
create index idx_clientes_estado on public.clientes (estado);
create index idx_clientes_nombre on public.clientes (nombre_completo);

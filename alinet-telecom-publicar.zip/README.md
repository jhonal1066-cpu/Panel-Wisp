# 📡 Alinet Telecom Manager — Gestión de Suscriptores

App en Streamlit para administrar los clientes de un WISP: directorio con
búsqueda y filtros, y formulario de registro. Los datos se guardan en Supabase.

## Estructura

| Archivo | Descripción |
|---|---|
| `schema_clientes.sql` | Crea la tabla `clientes` en Supabase (ejecutar una vez en el SQL Editor) |
| `database.py` | Módulo de datos: leer, crear y actualizar clientes |
| `clientes_ui.py` | Interfaz Streamlit (pestañas Directorio y Nuevo Registro) |
| `requirements.txt` | Dependencias de Python |
| `secrets.toml.example` | Plantilla de credenciales |

## Correr en su computadora

1. Ejecute `schema_clientes.sql` en el SQL Editor de Supabase (una sola vez).
2. Cree la carpeta `.streamlit/` junto a estos archivos y dentro un archivo
   `secrets.toml` (copie `secrets.toml.example` y ponga sus datos reales).
3. Instale y ejecute:

```sh
pip install -r requirements.txt
streamlit run clientes_ui.py
```

## Publicar gratis en la nube (Streamlit Community Cloud)

1. Suba este proyecto a un repositorio en **GitHub**.
   ⚠️ No suba `.streamlit/secrets.toml` (ya está excluido por `.gitignore`).
2. Entre a [share.streamlit.io](https://share.streamlit.io) con su cuenta de GitHub.
3. **Create app** → seleccione el repositorio →
   - Main file: `clientes_ui.py`
   - App URL: elija el nombre que quiera (ej. `alinet-telecom`)
4. Antes de lanzar, abra el menú **Advanced settings** y pegue las credenciales:

```toml
[supabase]
url = "https://SU-PROYECTO.supabase.co"
key = "SU-ANON-KEY"
```

5. Presione **Deploy**. En un minuto la app queda en
   `https://alinet-telecom.streamlit.app` — se abre desde el teléfono o cualquier PC.

Para actualizar la app después, solo suba los cambios a GitHub y se publican solos.
